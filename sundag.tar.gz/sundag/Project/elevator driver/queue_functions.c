
#include "main.h"
#include "elev.h"

#define N_CLIENTS 3

int add_to_queue(elev_button_type_t type, int  floor){
  if(type == BUTTON_CALL_UP && !queue[floor][1]){
    queue[floor][1] = 1;
    return 1; 
  }
  else if(type == BUTTON_CALL_DOWN && !queue[floor+2][1]){
    queue[floor+2][1] = 1;
    return 1;
  }
  else
    return 0;
}

Elevator elev_client[3];


//add_to_queue returns positive -> new order from outside
int cost_function(elev_button_type_t type, int floor){
  puts("Cost function: ");
  int direction;
  if(type==BUTTON_CALL_UP)
    direction = DIRN_UP;
  else
    direction = DIRN_DOWN;
  printf("DIRN: %d, FLOOR: %d\n", direction, floor);

  int delta=5; //Larger than possible delta FLOOR DIFFERANCE
  int client=-1; //Unavilable


//Elevator is available at the same floor
  for(int i=0;i<N_CLIENTS;i++){
    if(elev_client[i].direction == DIRN_STOP && elev_client[i].floor_current==floor){
      client=i;
    }
  }
  if(client!=-1){
    return client;
    //Finished
  }


//Elevator runs in the ordrered direction, and is stopping at the same floor
  for(int i=0;i<N_CLIENTS;i++){
    if(elev_client[i].direction == direction && elev_client[i].queue[floor]==1){
      if(abs(elev_client[i].floor_current-floor)<delta){
        delta=abs(elev_client[i].floor_current-floor);
        client =i;
      }   
    }
  }
  if(client!=-1){
    return client;
    //Finished
  }


//Elevator runs in the ordererd direction, but is not stopping at the same floor
  for(int i=0;i<N_CLIENTS;i++){
    if(elev_client[i].direction == direction){
      if(abs(elev_client[i].floor_current-floor)<delta){
        delta=abs(elev_client[i].floor_current-floor);
        client =i;
      }
    }
  }
  if(client!=-1){
    return client;
    //Finished
  }

//Elevator is available, but at a different floor
  for(int i=0;i<N_CLIENTS;i++){
    if(elev_client[i].direction == DIRN_STOP){
      if(abs(elev_client[i].floor_current-floor)<delta){
        delta=abs(elev_client[i].floor_current-floor);
        client =i;
      }
    } 
  }
  if(client=!-1){
    return client;
    //Finished
  }
  //At this point I know that all elevators are running in the wrong direction
  // -> I assign client 1
  client =0;
  return client;
}
