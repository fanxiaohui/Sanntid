#ifndef INITIALIZATIONS_H
#define INITIALIZATIONS_H


void connection_init(); //Checks if there exists a master, else become master
void client_init();		
void master_init();


#endif 