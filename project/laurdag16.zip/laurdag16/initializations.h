#ifndef INITALIZATIONS_H
#define INITALIZATIONS_H


void connection_init();
void client_init();
void boss_init();


#endif INITALIZATIONS_H