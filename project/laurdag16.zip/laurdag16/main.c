
#include <pthread.h> //for threading , link with lpthread
#include <semaphore.h>
#include <assert.h>
#include "main.h"
#include "lift.h"
#include "elev.h"
#include "communication.h"
#include "initializations.h"

int main(int argc , char *argv[])
{   
  
    

    connection_init();
     
    return 0;
}
