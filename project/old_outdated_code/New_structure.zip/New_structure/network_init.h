#ifndef NETWORK_INIT_H
#define NETWORK_INIT_H


void connection_init();
void client_init();
void boss_init();


#endif NETWORK_INIT_H