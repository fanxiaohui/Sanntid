#ifndef INITIALIZATIONS_H
#define INITIALIZATIONS_H


void connection_init();
void client_init();
void boss_init();


#endif NETWORK_INIT_H